import Task1
import Task2
import Task3

# regression task
task_1 = Task1.Task1()
task_1.model_1_run()
task_1.model_2_run()

# multi-category task
task_2 = Task2.Task2()
task_2.model_1_run()
task_2.model_2_run()

# multi-label task
task_3 = Task3.Task3()
task_3.model_1_run()
task_3.model_2_run()